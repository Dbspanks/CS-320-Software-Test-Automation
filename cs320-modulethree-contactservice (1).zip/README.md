# CS320 Module Three: Contact Service

## Overview
This project implements a contact management system in Java for SNHU's CS-320 Module Three milestone. It includes two core classes—`Contact` and `ContactService`—along with JUnit 5 test coverage to validate functionality and input constraints.

## Project Structure
CS320_ModuleThree_ContactService/
├── lib/
│   ├── junit-jupiter-api-5.9.3.jar
│   └── junit-platform-console-standalone-1.9.3.jar
├── src/
│   └── contactservice/
│       ├── Contact.java
│       ├── ContactService.java
│       ├── ContactTest.java
│       └── ContactServiceTest.java
├── README.md

## Testing Summary
JUnit 5 tests validate:
- Field constraints and setters in `ContactTest`
- CRUD operations and exception handling in `ContactServiceTest`
- Edge cases including nulls, invalid formats, and duplicate IDs

All tests pass successfully:
- 11 tests executed
- 0 failures
- 0 skipped

## How to Compile and Run Tests

### Step 1: Compile
javac -cp ".:lib/junit-jupiter-api-5.9.3.jar" src/contactservice/*.java

### Step 2: Run Tests
java -jar lib/junit-platform-console-standalone-1.9.3.jar \
--class-path .:lib/junit-jupiter-api-5.9.3.jar:src \
--scan-class-path

## Milestone Compliance
- All required classes and methods implemented
- Input validation enforced
- JUnit 5 tests pass with no errors
- Project follows SNHU guidelines and rubric

## Author
Danny Forte  
Southern New Hampshire University  
CS-320 Software Test, Automation, and QA  
Fall 2025
