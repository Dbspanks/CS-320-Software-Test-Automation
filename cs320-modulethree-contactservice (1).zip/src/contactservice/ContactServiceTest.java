package contactservice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContactSuccessfully() {
        Contact contact = new Contact("DF001", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertEquals(contact, service.getContactById("DF001"));
    }

    @Test
    public void testAddDuplicateContactThrowsException() {
        Contact contact = new Contact("DF001", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        Contact duplicate = new Contact("DF001", "Dan", "Forte", "6175559999", "99 Elm St");
        assertThrows(IllegalArgumentException.class, () -> service.addContact(duplicate));
    }

    @Test
    public void testDeleteContactSuccessfully() {
        Contact contact = new Contact("DF002", "Rebecca", "Forte", "6175556789", "22 Summer St");
        service.addContact(contact);
        service.deleteContact("DF002");
        assertThrows(IllegalArgumentException.class, () -> service.getContactById("DF002"));
    }

    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("DF003", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        service.updateFirstName("DF003", "Dan");
        assertEquals("Dan", service.getContactById("DF003").getFirstName());
    }

    @Test
    public void testUpdatePhoneWithInvalidValueThrowsException() {
        Contact contact = new Contact("DF004", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("DF004", "123"));
    }

    @Test
    public void testUpdateAddressWithNullThrowsException() {
        Contact contact = new Contact("DF005", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("DF005", null));
    }
}
