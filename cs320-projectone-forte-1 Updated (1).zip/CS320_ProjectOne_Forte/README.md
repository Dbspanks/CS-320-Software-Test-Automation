# Appointment Service – Project One Submission

Author: Danny Forte  
Course: CS-320 Secure Software Development – Southern New Hampshire University  
Date: October 10, 2025

## Project Overview

This Java application manages appointment records with strict validation for ID, date, and description. It includes a service layer for adding, deleting, and retrieving appointments, and uses JUnit 5.9.3 for unit testing. The project emphasizes secure coding practices, exception handling, and academic integrity.

## Folder Structure

CS320_ProjectOne_Forte/
├── src/
│   ├── appointment/
│   │   ├── Appointment.java
│   │   └── AppointmentService.java
│   ├── contact/
│   │   ├── Contact.java
│   │   └── ContactService.java
│   ├── task/
│   │   ├── Task.java
│   │   └── TaskService.java
├── test/
│   ├── appointment/
│   │   ├── AppointmentTest.java
│   │   └── AppointmentServiceTest.java
│   ├── contact/
│   │   ├── ContactTest.java
│   │   └── ContactServiceTest.java
│   ├── task/
│   │   ├── TaskTest.java
│   │   └── TaskServiceTest.java
├── lib/
│   ├── junit-jupiter-api-5.9.3.jar
│   ├── junit-jupiter-engine-5.9.3.jar
│   ├── opentest4j-1.2.0.jar
│   └── apiguardian-api-1.1.2.jar

## Test Coverage Summary

AppointmentTest.java:
- Validates constructor constraints (null checks, length limits, future date enforcement)
- Confirms immutability and field integrity

AppointmentServiceTest.java:
- Covers add, delete, duplicate ID, missing ID, and getAllAppointments() functionality

ContactTest.java:
- Validates phone number format, ID length, and field setters
- Confirms rejection of invalid updates

ContactServiceTest.java:
- Covers add, delete, duplicate ID, update methods, and getAllContacts()

TaskTest.java:
- Validates constructor constraints and field setters
- Confirms immutability and rejection of invalid inputs

TaskServiceTest.java:
- Covers add, delete, update, duplicate ID, and getAllTasks()

Coverage Estimate: 100% of public methods and validation logic across all model and service classes

## How to Compile and Run

Compile:
javac -cp ".:lib/*" src/*/*.java test/*/*.java

Run All Tests:
java -cp ".:lib/*:src:test" org.junit.platform.console.ConsoleLauncher --scan-class-path

Note: On Windows, replace ":" with ";" in the classpath.

## Validation Summary

-All 43 tests passed successfully
-Application enforces all constraints and handles exceptions as expected
-No external dependencies beyond JUnit 5
-All code is original and adheres to SNHU’s academic integrity policies