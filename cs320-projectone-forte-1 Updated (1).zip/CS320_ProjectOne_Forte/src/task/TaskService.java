// Author: Danny Forte
// CS-320 Project One – Task Service
// This class manages in-memory storage and operations for Task objects.
// Supports add, update, delete, and retrieval by task ID.
package task;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

public class TaskService {
    // Internal map to store tasks by their unique ID
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a new task to the service.
     * Validates uniqueness of task ID before adding.
     *
     * @param taskId      Unique ID for the task
     * @param name        Task name
     * @param description Task description
     */
    public void addTask(String taskId, String name, String description) {
        if (tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID already exists: " + taskId);
        }
        Task task = new Task(taskId, name, description);
        tasks.put(taskId, task);
    }

    /**
     * Deletes a task from the service by its ID.
     * Throws an exception if the task ID is not found.
     *
     * @param taskId ID of the task to delete
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new NoSuchElementException("Task ID not found: " + taskId);
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name of a task by its ID.
     * Throws an exception if the task ID is not found.
     *
     * @param taskId  ID of the task to update
     * @param newName New name for the task
     */
    public void updateTaskName(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new NoSuchElementException("Task ID not found: " + taskId);
        }
        task.setName(newName);
    }

    /**
     * Updates the description of a task by its ID.
     * Throws an exception if the task ID is not found.
     *
     * @param taskId         ID of the task to update
     * @param newDescription New description for the task
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new NoSuchElementException("Task ID not found: " + taskId);
        }
        task.setDescription(newDescription);
    }

    /**
     * Retrieves a task by its ID.
     * Returns null if the task is not found.
     *
     * @param taskId ID of the task to retrieve
     * @return Task object or null
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
        /**
     * Retrieves all tasks currently stored in the service.
     * Returns a shallow copy to preserve encapsulation.
     *
     * @return Map of task IDs to Task objects
     */
    public Map<String, Task> getAllTasks() {
        return new HashMap<>(tasks);
    }
}
