package appointment;

import java.util.HashMap;
import java.util.Map;

/**
 * Author: Danny Forte
 * CS-320 Project One – Appointment Service
 * Description: Service class for managing Appointment objects using in-memory storage.
 */

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();
/**
 * Adds a new appointment if the ID is unique.
 * @param appointment the Appointment object to add
 * @throws IllegalArgumentException if the ID already exists
 */

    public void addAppointment(Appointment appointment) {
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        appointments.put(id, appointment);
    }
/**
 * Deletes an appointment by ID.
 * @param appointmentId the ID of the appointment to delete
 * @throws IllegalArgumentException if the ID is not found
 */

    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        appointments.remove(appointmentId);
    }

/**
 * Retrieves an appointment by ID.
 * Useful for testing or internal access.
 */


    public Appointment getAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        return appointments.get(appointmentId);
    }
/**
 * Returns a copy of all appointments.
 * Useful for testing or debugging.
 */
    public Map<String, Appointment> getAllAppointments() {
        return new HashMap<>(appointments);
    }
}
