package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;
import java.util.Map;
/**
 * Author: Danny Forte
 * CS-320 Project One – Appointment Service Test
 * Description: Unit tests for AppointmentService to verify add/delete functionality and exception handling.
 */

public class AppointmentServiceTest {

    private AppointmentService service;
    private Date futureDate;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1); // Set to tomorrow
        futureDate = cal.getTime();
    }

    @Test
    public void testAddValidAppointment() {
        Appointment appt = new Appointment("NHU2025", futureDate, "Capstone planning session");
        service.addAppointment(appt);
        assertNotNull(service.getAppointment("NHU2025"));
    }
    @Test
    public void testAppointmentDateMustBeInFuture() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1); // Set to yesterday
        Date pastDate = cal.getTime();

        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("PAST001", pastDate, "Should fail due to past date")
        );
    }
    @Test
    public void testAddDuplicateAppointmentIdThrowsException() {
        Appointment appt1 = new Appointment("FRT2025", futureDate, "Security audit");
        Appointment appt2 = new Appointment("FRT2025", futureDate, "Code review");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    @Test
    public void testDeleteExistingAppointment() {
        Appointment appt = new Appointment("OCT04AM", futureDate, "Team sync-up");
        service.addAppointment(appt);
        service.deleteAppointment("OCT04AM");
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment("OCT04AM"));
    }

    @Test
    public void testDeleteNonExistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NONEXISTENT"));
    }
    // Test for getAllAppointments method
    @Test
    public void testGetAllAppointmentsReturnsCorrectSize() {
        Appointment appt1 = new Appointment("ID001", futureDate, "First appointment");
        Appointment appt2 = new Appointment("ID002", futureDate, "Second appointment");
        service.addAppointment(appt1);
        service.addAppointment(appt2);

        Map<String, Appointment> allAppointments = service.getAllAppointments();
        assertEquals(2, allAppointments.size());
        assertTrue(allAppointments.containsKey("ID001"));
        assertTrue(allAppointments.containsKey("ID002"));
    }
}
