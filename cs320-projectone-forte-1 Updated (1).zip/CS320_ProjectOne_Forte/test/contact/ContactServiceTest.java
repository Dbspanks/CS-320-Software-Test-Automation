/**
 * Author: Danny Forte
 * CS-320 Project One – Contact Service Test
 * Description: Unit tests for ContactService to verify add/delete/update functionality and exception handling.
 */
package contact;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Map;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    // ─────────────────────────────────────────────────────────────
    // Add Contact Tests
    // ─────────────────────────────────────────────────────────────
    @Test
    public void testAddContactSuccessfully() {
        Contact contact = new Contact("DF001", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertEquals(contact, service.getContactById("DF001"));
    }

    @Test
    public void testAddDuplicateContactThrowsException() {
        Contact contact = new Contact("DF001", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        Contact duplicate = new Contact("DF001", "Dan", "Forte", "6175559999", "99 Elm St");
        assertThrows(IllegalArgumentException.class, () -> service.addContact(duplicate));
    }

    // ─────────────────────────────────────────────────────────────
    // Delete Contact Tests
    // ─────────────────────────────────────────────────────────────
    @Test
    public void testDeleteContactSuccessfully() {
        Contact contact = new Contact("DF002", "Rebecca", "Forte", "6175556789", "22 Summer St");
        service.addContact(contact);
        service.deleteContact("DF002");
        assertThrows(IllegalArgumentException.class, () -> service.getContactById("DF002"));
    }

    @Test
    public void testDeleteNonExistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("UNKNOWN_ID"));
    }

    // ─────────────────────────────────────────────────────────────
    // Update Contact Tests – Valid Inputs
    // ─────────────────────────────────────────────────────────────
    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("DF003", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        service.updateFirstName("DF003", "Dan");
        assertEquals("Dan", service.getContactById("DF003").getFirstName());
    }

    // ─────────────────────────────────────────────────────────────
    // Update Contact Tests – Invalid Inputs
    // ─────────────────────────────────────────────────────────────
    @Test
    public void testUpdatePhoneWithInvalidValueThrowsException() {
        Contact contact = new Contact("DF004", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("DF004", "123"));
    }

    @Test
    public void testUpdatePhoneWithNonDigitCharactersThrowsException() {
        Contact contact = new Contact("DF009", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("DF009", "abcde12345"));
    }

    @Test
    public void testUpdateAddressWithNullThrowsException() {
        Contact contact = new Contact("DF005", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("DF005", null));
    }

    @Test
    public void testUpdateAddressWithEmptyStringThrowsException() {
        Contact contact = new Contact("DF008", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("DF008", ""));
    }

    @Test
    public void testUpdateFirstNameWithNullThrowsException() {
        Contact contact = new Contact("DF010", "Danny", "Forte", "6175551234", "15 Highland Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("DF010", null));
    }

    @Test
    public void testUpdateNonExistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("BAD_ID", "6175550000"));
    }

    // ─────────────────────────────────────────────────────────────
    // Retrieval Tests
    // ─────────────────────────────────────────────────────────────
    @Test
    public void testGetAllContactsReturnsCorrectSize() {
        Contact contact1 = new Contact("DF006", "Alice", "Smith", "6175551111", "10 Main St");
        Contact contact2 = new Contact("DF007", "Bob", "Jones", "6175552222", "20 Oak St");
        service.addContact(contact1);
        service.addContact(contact2);

        Map<String, Contact> allContacts = service.getAllContacts();
        assertEquals(2, allContacts.size());
        assertTrue(allContacts.containsKey("DF006"));
        assertTrue(allContacts.containsKey("DF007"));
    }
}