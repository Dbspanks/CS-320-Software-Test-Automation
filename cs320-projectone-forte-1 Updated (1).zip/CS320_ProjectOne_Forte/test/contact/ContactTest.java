/**
 * Author: Danny Forte
 * CS-320 Project One – Contact Test
 * Description: Unit tests for Contact class to verify field constraints and setter behavior.
 */

package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("DF001", "Danny", "Forte", "6175551234", "15 Highland Ave");
        assertEquals("DF001", contact.getContactId());
        assertEquals("Danny", contact.getFirstName());
        assertEquals("Forte", contact.getLastName());
        assertEquals("6175551234", contact.getPhone());
        assertEquals("15 Highland Ave", contact.getAddress());
    }

    @Test
    public void testInvalidContactIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Danny", "Forte", "6175551234", "15 Highland Ave");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TOO_LONG_ID_123", "Danny", "Forte", "6175551234", "15 Highland Ave");
        });
    }

    @Test
    public void testInvalidPhoneThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("DF002", "Danny", "Forte", "123", "15 Highland Ave");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("DF003", "Danny", "Forte", "abcdefghij", "15 Highland Ave");
        });
    }

    @Test
    public void testSettersUpdateFieldsCorrectly() {
        Contact contact = new Contact("DF004", "Danny", "Forte", "6175551234", "15 Highland Ave");
        contact.setFirstName("Dan");
        contact.setLastName("Forté");
        contact.setPhone("6175556789");
        contact.setAddress("22 Summer St");

        assertEquals("Dan", contact.getFirstName());
        assertEquals("Forté", contact.getLastName());
        assertEquals("6175556789", contact.getPhone());
        assertEquals("22 Summer St", contact.getAddress());
    }

    @Test
    public void testSettersRejectInvalidValues() {
        Contact contact = new Contact("DF005", "Danny", "Forte", "6175551234", "15 Highland Ave");

        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ThisNameIsWayTooLong"));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123"));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }
}
