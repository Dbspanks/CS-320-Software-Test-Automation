
import java.util.HashMap;
import java.util.Map;

/**
 * Author: Danny Forte
 * Course: CS at Southern New Hampshire University
 * Description: Service class for managing Appointment objects using in-memory storage.
 */

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        appointments.put(id, appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        appointments.remove(appointmentId);
    }

    // Optional helper for testing visibility
    public Appointment getAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        return appointments.get(appointmentId);
    }
}
