import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

/**
 * Author: Danny Forte
 * Course: CS at Southern New Hampshire University
 * Description: Unit tests for Appointment class to verify field constraints and object creation.
 */

public class AppointmentTest {

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1); // Tomorrow
        return cal.getTime();
    }

    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1); // Yesterday
        return cal.getTime();
    }

    @Test
    public void testValidAppointmentCreation() {
        Appointment appt = new Appointment("NHU2025", getFutureDate(), "Capstone planning session");
        assertEquals("NHU2025", appt.getAppointmentId());
        assertEquals("Capstone planning session", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    @Test
    public void testNullAppointmentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Valid description");
        });
    }

    @Test
    public void testLongAppointmentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("TOO_LONG_ID_123", getFutureDate(), "Valid description");
        });
    }

    @Test
    public void testNullAppointmentDateThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("NHU2025", null, "Valid description");
        });
    }

    @Test
    public void testPastAppointmentDateThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("NHU2025", getPastDate(), "Valid description");
        });
    }

    @Test
    public void testNullDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("NHU2025", getFutureDate(), null);
        });
    }

    @Test
    public void testLongDescriptionThrowsException() {
        String longDesc = "This description is definitely more than fifty characters long and should fail.";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("NHU2025", getFutureDate(), longDesc);
        });
    }
}
