import java.util.Date;

/**
 * Author: Danny Forte
 * Course: CS at Southern New Hampshire University
 * Description: Represents an appointment with ID, date, and description. Validates constraints on creation.
 */

public class Appointment {

    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate appointmentId
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be non-null and ≤ 10 characters.");
        }

        // Validate appointmentDate
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must be non-null and not in the past.");
        }

        // Validate description
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and ≤ 50 characters.");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}
