# # Appointment Service – Milestone 6

Author: Danny Forte  
Course: CS at Southern New Hampshire University  
Module: 6 – Secure Software Development  
Date: October 4, 2025

## Project Overview

This Java application manages appointment records with strict validation for ID, date, and description. It includes a service layer for adding and deleting appointments and uses JUnit 5.9.3 for unit testing. The project emphasizes secure coding, exception handling, and academic integrity.

## Folder Structure

AppointmentService_Milestone6/
├── src/
│   ├── Appointment.java
│   ├── AppointmentService.java
│   ├── AppointmentTest.java
│   └── AppointmentServiceTest.java
├── lib/
│   ├── junit-jupiter-api-5.9.3.jar
│   ├── junit-jupiter-engine-5.9.3.jar
│   ├── opentest4j-1.2.0.jar
│   └── apiguardian-api-1.1.2.jar

## Test Coverage

- AppointmentTest.java: Validates constructor constraints (null checks, length limits, date validation)
- AppointmentServiceTest.java: Covers add, delete, duplicate ID, and missing ID scenarios
- Coverage Estimate: ~85–90% of functional requirements
- JUnit Version: 5.9.3 with ConsoleLauncher

## How to Compile and Run

Compile:
javac -cp ".:lib/*" src/*.java

Run Tests:
java -cp ".:lib/*:src" org.junit.platform.console.ConsoleLauncher --select-class AppointmentTest
java -cp ".:lib/*:src" org.junit.platform.console.ConsoleLauncher --select-class AppointmentServiceTest

Note: On Windows, replace ":" with ";" in the classpath.

## Validation Summary

All tests passed successfully. The application enforces all constraints and handles exceptions as expected. No external dependencies beyond JUnit 5 are required.

All code is original and adheres to SNHU’s academic integrity policies.


