// Author: Danny Forte
// CS-320 Module 4 Milestone – Task Service
// This class defines a Task object with strict validation rules.
// Each Task has a unique, immutable ID, a name, and a description.

public class Task {
    // Immutable unique task ID (max 10 characters)
    private final String taskId;

    // Task name (max 20 characters)
    private String name;

    // Task description (max 50 characters)
    private String description;

    /**
     * Constructor to initialize a Task object.
     * Validates all fields according to project requirements.
     *
     * @param taskId      Unique ID for the task (non-null, ≤ 10 chars)
     * @param name        Task name (non-null, ≤ 20 chars)
     * @param description Task description (non-null, ≤ 50 chars)
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must be ≤ 10 characters and not null");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name must be ≤ 20 characters and not null");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be ≤ 50 characters and not null");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    /**
     * Returns the task ID.
     * This field is immutable and cannot be changed after creation.
     *
     * @return taskId
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * Returns the task name.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the task name.
     * Validates that the new name is non-null and ≤ 20 characters.
     *
     * @param name New task name
     */
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name must be ≤ 20 characters and not null");
        }
        this.name = name;
    }

    /**
     * Returns the task description.
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Updates the task description.
     * Validates that the new description is non-null and ≤ 50 characters.
     *
     * @param description New task description
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be ≤ 50 characters and not null");
        }
        this.description = description;
    }
}
