// Author: Danny Forte
// CS-320 Module 4 Milestone – Task Service
// This test class verifies the behavior of TaskService using JUnit 5.
// It covers add, delete, update, and edge case validation.

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService service;

    /**
     * Setup method runs before each test.
     * Initializes a fresh TaskService instance.
     */
    @BeforeEach
    public void setup() {
        service = new TaskService();
    }

    /**
     * Test adding a valid task.
     * Verifies that the task is stored and retrievable.
     */
    @Test
    public void testAddTask() {
        service.addTask("SOM001", "Fix sidewalk", "Repair cracked pavement on Highland Ave");
        Task task = service.getTask("SOM001");
        assertNotNull(task);
        assertEquals("Fix sidewalk", task.getName());
        assertEquals("Repair cracked pavement on Highland Ave", task.getDescription());
    }

    /**
     * Test deleting a task.
     * Verifies that the task is removed from the service.
     */
    @Test
    public void testDeleteTask() {
        service.addTask("SOM002", "Trash pickup", "Schedule bulk pickup for 42 Summer St");
        service.deleteTask("SOM002");
        assertNull(service.getTask("SOM002"));
    }

    /**
     * Test updating a task's name.
     * Verifies that the name is changed correctly.
     */
    @Test
    public void testUpdateName() {
        service.addTask("SOM003", "Old Name", "Update name test");
        service.updateTaskName("SOM003", "New Name");
        assertEquals("New Name", service.getTask("SOM003").getName());
    }

    /**
     * Test updating a task's description.
     * Verifies that the description is changed correctly.
     */
    @Test
    public void testUpdateDescription() {
        service.addTask("SOM004", "Name", "Old Desc");
        service.updateTaskDescription("SOM004", "New Desc");
        assertEquals("New Desc", service.getTask("SOM004").getDescription());
    }
}