// Author: Danny Forte
// CS-320 Module 4 Milestone – Task Service
// This test class verifies the behavior of the Task object using JUnit 5.
// It covers constructor validation, field updates, immutability of task ID, and input constraints.

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("SOM001", "Fix sidewalk", "Repair cracked pavement on Highland Ave");
        assertEquals("SOM001", task.getTaskId());
        assertEquals("Fix sidewalk", task.getName());
        assertEquals("Repair cracked pavement on Highland Ave", task.getDescription());
    }

    @Test
    void testTaskIdImmutability() {
        Task task = new Task("SOM002", "Trash pickup", "Schedule bulk pickup for 42 Summer St");
        assertEquals("SOM002", task.getTaskId());
        // No setter exists, so we confirm immutability by absence of mutation
    }

    @Test
    void testSetName() {
        Task task = new Task("SOM003", "Old Name", "Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    void testSetDescription() {
        Task task = new Task("SOM004", "Task Name", "Old Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    // --- Field Length Validation Tests ---

    @Test
    void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Valid Name", "Valid Description");
        });
    }

    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("SOM005", "This name is definitely too long", "Valid Description");
        });
    }

    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("SOM006", "Valid Name", "This is a test task with an extra extra long description");
        });
    }

    // --- Null Field Validation Tests ---

    @Test
    void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Valid Name", "Valid Description");
        });
    }

    @Test
    void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("SOM007", null, "Valid Description");
        });
    }

    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("SOM008", "Valid Name", null);
        });
    }
}
