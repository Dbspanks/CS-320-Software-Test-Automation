# CS320 Module Four: Task Service

## Overview
This project implements a task management system in Java for SNHU’s CS-320 Module Four milestone. It includes two core classes—Task and TaskService—along with comprehensive JUnit 5 test coverage to validate functionality, input constraints, and service operations.

## Project Structure

TaskService_M4_Forte/
├── lib/
│   ├── junit-jupiter-api-5.9.3.jar
│   └── junit-platform-console-standalone-1.9.3.jar
├── src/
│   ├── Task.java
│   └── TaskService.java
├── test/
│   ├── TaskTest.java
│   └── TaskServiceTest.java
├── README.md

## Testing Summary
JUnit 5 tests validate:
- Field constraints and null checks in TaskTest
- Setter behavior and immutability of taskId
- CRUD operations and exception handling in TaskServiceTest
- Edge cases including invalid formats and duplicate IDs

All tests pass successfully:
- ✅ 14 tests executed  
- ✅ 0 failures  
- ✅ 0 skipped

## How to Compile and Run Tests

### Step 1: Compile
javac -cp "lib/junit-jupiter-api-5.9.3.jar" src/*.java test/*.java

### Step 2: Run Tests
java -jar lib/junit-platform-console-standalone-1.9.3.jar --class-path .:src:test --scan-class-path

## Milestone Compliance
- ✅ All required classes and methods implemented
- ✅ Input validation enforced for length and null constraints
- ✅ JUnit 5 tests pass with no errors
- ✅ Project follows SNHU guidelines and rubric
- ✅ Personalized with Somerville-style realism for authenticity

---

**Author:** Danny Forte  
**Institution:** Southern New Hampshire University  
**Course:** CS-320 Software Test, Automation, and QA  
**Term:** Fall 2025
